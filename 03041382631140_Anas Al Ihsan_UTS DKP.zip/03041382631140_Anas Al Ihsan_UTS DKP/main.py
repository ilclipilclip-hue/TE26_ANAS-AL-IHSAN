data_arus = [1.6, 2.2, 3.5, 4.1, 5.4, 
             2.8, 6.0, 3.9, 1.9, 4.8, 
             5.1, 2.6, 3.2, 4.4, 5.8,  
             3.0, 4.5, 2.7, 3.8, 5.2] # 20 data utama


#data_arus = [3.6, 0.2, 0.5, 1.1, 1.4, 3.2, 2.1, 4.3] # 8 data uji coba

# hitung daya   
# status beban 
# hitung rata rata data

def hitung_daya(V, I):
    return V * I

def status_beban(data):
    daya = hitung_daya(220, rata_rata(data))
    if daya < 700:
        return "NORMAL"#aman
    elif daya < 1000:
        return "WARNING"#oke
    else:
        return "BEBAN TINGGI"#bahaya

def rata_rata(data):
    total = 0
    for nilai in data:
        total += nilai
    return total / len(data)

P = hitung_daya(220, rata_rata(data_arus))
print(P, status_beban(data_arus))

print("----- Hasil Perhitungan Daya Listrik -----")

for i in range(len(data_arus)):
    daya = hitung_daya(220, data_arus[i])
    status = status_beban(data_arus)
    print(f"Data Arus ke-{i+1}: {data_arus[i]} A, Daya: {daya} W")

rata = rata_rata(data_arus)
average_daya = hitung_daya(220, rata)
print(f"\nRata-rata Arus: {rata:.2f} A")
print(f"Rata-rata Daya: {average_daya:.2f} W")

print()
print("----- RINGKASAN -----")
print("Total Data:", len(data_arus))
print("NORMAL:", sum(1 for x in data_arus if status_beban([x]) == "NORMAL"))
print("WARNING:", sum(1 for x in data_arus if status_beban([x]) == "WARNING"))
print("BEBAN TINGGI:", sum(1 for x in data_arus if status_beban([x]) == "BEBAN TINGGI"))
print("Rata-rata Daya:", round(average_daya, 2), "W")
print("minimum Daya:", round(hitung_daya(220, min(data_arus)), 2), "W")
print("maximum Daya:", round(hitung_daya(220, max(data_arus)), 2), "W")